/* Nira theme — cart drawer, product gallery, mobile menu */
(function () {
  const $ = (s, r = document) => r.querySelector(s)
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s))

  /* mobile menu */
  const mnav = $('#mnav')
  $('#menu-open')?.addEventListener('click', () => mnav?.classList.add('open'))
  $('#menu-close')?.addEventListener('click', () => mnav?.classList.remove('open'))

  /* product gallery */
  $$('.pdp__thumb').forEach((btn) => {
    btn.addEventListener('click', () => {
      const main = $('#pdp-main')
      if (main && btn.dataset.src) main.src = btn.dataset.src
      $$('.pdp__thumb').forEach((b) => b.classList.remove('on'))
      btn.classList.add('on')
    })
  })

  /* qty steppers */
  $$('[data-qty]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input')
      const next = Math.max(1, (parseInt(input.value, 10) || 1) + parseInt(btn.dataset.qty, 10))
      input.value = next
    })
  })

  /* cart drawer */
  const drawer = $('#cart-drawer')
  const body = $('#cart-body')
  const count = $('#cart-count')

  function renderCart(cart) {
    if (!body) return
    count.textContent = cart.item_count
    $$('.badge').forEach((b) => (b.textContent = cart.item_count))
    if (!cart.items.length) {
      body.innerHTML = '<p style="padding:20px 0;color:#6b6b6b;font-size:13px">Your bag is empty.</p>'
      return
    }
    body.innerHTML = cart.items
      .map(
        (i) => `<div class="drawer__item">
          <img src="${i.image ? i.image.replace(/(\.[a-z]+)(\?|$)/, '_120x144$1$2') : ''}" alt="">
          <div><b>${i.product_title}</b><br><span style="color:#6b6b6b">${i.variant_title || ''} × ${i.quantity}</span></div>
          <span>${Shopify.formatMoney(i.final_line_price)}</span>
        </div>`
      )
      .join('')
  }

  async function refreshCart() {
    const res = await fetch(window.themeRoutes.cart + '.js')
    renderCart(await res.json())
  }

  $('#cart-open')?.addEventListener('click', async () => {
    drawer.classList.add('open')
    await refreshCart()
  })
  $('#cart-close')?.addEventListener('click', () => drawer.classList.remove('open'))

  /* ajax add to cart */
  const form = $('#pdp-form')
  form?.addEventListener('submit', async (e) => {
    e.preventDefault()
    const btn = form.querySelector('.pdp__add')
    const label = btn.textContent
    btn.textContent = 'Adding…'
    try {
      const res = await fetch(window.themeRoutes.add + '.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          items: [{ id: Number(form.querySelector('[name=id]').value), quantity: Number(form.querySelector('[name=quantity]').value) }]
        })
      })
      if (!res.ok) throw new Error('add failed')
      drawer.classList.add('open')
      await refreshCart()
      btn.textContent = 'Added ✓'
      setTimeout(() => (btn.textContent = label), 1600)
    } catch (err) {
      btn.textContent = label
      form.submit()
    }
  })
})()

/* ---------- hero slider ---------- */
(function () {
  document.querySelectorAll('.hslider').forEach((root) => {
    const slides = [...root.querySelectorAll('.hslider__slide')]
    const dots = [...root.querySelectorAll('.hslider__dots button')]
    if (slides.length < 2) return
    let i = 0
    let timer = null
    const go = (n) => {
      i = (n + slides.length) % slides.length
      slides.forEach((s, k) => s.classList.toggle('on', k === i))
      dots.forEach((d, k) => d.classList.toggle('on', k === i))
    }
    const start = () => {
      if (root.dataset.autoplay !== 'true') return
      clearInterval(timer)
      timer = setInterval(() => go(i + 1), (Number(root.dataset.speed) || 6) * 1000)
    }
    root.querySelectorAll('.hslider__nav').forEach((b) =>
      b.addEventListener('click', () => { go(i + Number(b.dataset.dir)); start() })
    )
    dots.forEach((d, k) => d.addEventListener('click', () => { go(k); start() }))
    root.addEventListener('mouseenter', () => clearInterval(timer))
    root.addEventListener('mouseleave', start)
    start()
  })
})()

/* ---------- runway rail: drag + wheel ---------- */
(function () {
  document.querySelectorAll('.rwrail').forEach((rail) => {
    let down = false, startX = 0, startScroll = 0
    rail.addEventListener('pointerdown', (e) => {
      down = true; startX = e.clientX; startScroll = rail.scrollLeft
      rail.classList.add('dragging'); rail.setPointerCapture(e.pointerId)
    })
    rail.addEventListener('pointermove', (e) => {
      if (!down) return
      rail.scrollLeft = startScroll - (e.clientX - startX)
    })
    const end = () => { down = false; rail.classList.remove('dragging') }
    rail.addEventListener('pointerup', end)
    rail.addEventListener('pointercancel', end)
    rail.addEventListener('pointerleave', end)
  })
})()

/* ---------- offers: copy code ---------- */
document.querySelectorAll('.offer3d__code').forEach((b) => {
  b.addEventListener('click', async () => {
    const code = b.dataset.code || b.textContent.trim()
    try { await navigator.clipboard.writeText(code); b.textContent = 'Copied ✓'; setTimeout(() => (b.textContent = code), 1500) } catch {}
  })
})

/* ---------- predictive search ---------- */
(function () {
  const input = document.getElementById('ps-input')
  const box = document.getElementById('ps-results')
  if (!input || !box) return
  let t = null
  input.addEventListener('input', () => {
    const q = input.value.trim()
    clearTimeout(t)
    if (q.length < 2) { box.hidden = true; return }
    t = setTimeout(async () => {
      try {
        const res = await fetch(`/search/suggest.json?q=${encodeURIComponent(q)}&resources[type]=product&resources[limit]=5`)
        const data = await res.json()
        const items = data.resources?.results?.products || []
        box.innerHTML = items.length
          ? items.map((p) => `<a class="ps__item" href="${p.url}">
              ${p.featured_image ? `<img src="${p.featured_image.url}" alt="">` : '<span></span>'}
              <span><b>${p.title}</b><br><span>${p.price}</span></span>
              <span>→</span></a>`).join('')
          : '<p style="padding:12px;font-size:12.5px;color:#8a8a8a">No matches</p>'
        box.hidden = false
      } catch { box.hidden = true }
    }, 220)
  })
  document.addEventListener('click', (e) => { if (!box.contains(e.target) && e.target !== input) box.hidden = true })
})()
