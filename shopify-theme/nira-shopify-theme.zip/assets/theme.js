/* Nira theme — cart drawer, product gallery, mobile menu */
(function () {
  const $ = (s, r = document) => r.querySelector(s)
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s))

  /* mobile menu */
  const mnav = $('#mnav')
  $('#menu-open')?.addEventListener('click', () => mnav?.classList.add('open'))
  $('#menu-close')?.addEventListener('click', () => mnav?.classList.remove('open'))

  /* product gallery */
  $$('.pdp__thumb').forEach((btn) => {
    btn.addEventListener('click', () => {
      const main = $('#pdp-main')
      if (main && btn.dataset.src) main.src = btn.dataset.src
      $$('.pdp__thumb').forEach((b) => b.classList.remove('on'))
      btn.classList.add('on')
    })
  })

  /* qty steppers */
  $$('[data-qty]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input')
      const next = Math.max(1, (parseInt(input.value, 10) || 1) + parseInt(btn.dataset.qty, 10))
      input.value = next
    })
  })

  /* cart drawer */
  const drawer = $('#cart-drawer')
  const body = $('#cart-body')
  const count = $('#cart-count')

  function renderCart(cart) {
    if (!body) return
    count.textContent = cart.item_count
    $$('.badge').forEach((b) => (b.textContent = cart.item_count))
    if (!cart.items.length) {
      body.innerHTML = '<p style="padding:20px 0;color:#6b6b6b;font-size:13px">Your bag is empty.</p>'
      return
    }
    body.innerHTML = cart.items
      .map(
        (i) => `<div class="drawer__item">
          <img src="${i.image ? i.image.replace(/(\.[a-z]+)(\?|$)/, '_120x144$1$2') : ''}" alt="">
          <div><b>${i.product_title}</b><br><span style="color:#6b6b6b">${i.variant_title || ''} × ${i.quantity}</span></div>
          <span>${Shopify.formatMoney(i.final_line_price)}</span>
        </div>`
      )
      .join('')
  }

  async function refreshCart() {
    const res = await fetch(window.themeRoutes.cart + '.js')
    renderCart(await res.json())
  }

  $('#cart-open')?.addEventListener('click', async () => {
    drawer.classList.add('open')
    await refreshCart()
  })
  $('#cart-close')?.addEventListener('click', () => drawer.classList.remove('open'))

  /* ajax add to cart */
  const form = $('#pdp-form')
  form?.addEventListener('submit', async (e) => {
    e.preventDefault()
    const btn = form.querySelector('.pdp__add')
    const label = btn.textContent
    btn.textContent = 'Adding…'
    try {
      const res = await fetch(window.themeRoutes.add + '.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          items: [{ id: Number(form.querySelector('[name=id]').value), quantity: Number(form.querySelector('[name=quantity]').value) }]
        })
      })
      if (!res.ok) throw new Error('add failed')
      drawer.classList.add('open')
      await refreshCart()
      btn.textContent = 'Added ✓'
      setTimeout(() => (btn.textContent = label), 1600)
    } catch (err) {
      btn.textContent = label
      form.submit()
    }
  })
})()
